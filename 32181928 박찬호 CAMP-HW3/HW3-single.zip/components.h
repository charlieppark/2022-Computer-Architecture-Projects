#ifndef __COMP_H__
#define __COMP_H__

#include <stdbool.h>
#include <stdlib.h>

#include "latch.h"
#include "alu.h"

#include "components.h"

int adder(int a, int b);
int alu(int a, int b, int* zero, int opcode, int funct);
bool and_gate(bool a, bool b);
void** control_unit(int opcode);
int data_memory (int address, int write_data, bool MemWrite, bool MemRead, int* memory);
int mux(bool signal, int if_false, int if_true);
int* operate_registers(int* registers, bool RegWrite, int read_register_1, int read_register_2, int write_register, int write_data);
int read_instruction(int address, int* instruction_memory);
int shitf_left_two(int a);
int sign_extend(short instruction_15_0);

#endif // !__COMP_H__