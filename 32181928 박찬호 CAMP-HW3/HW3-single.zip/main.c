#include <stdio.h>
#include <stdlib.h>

#include <stdbool.h>

#include "instruction.h"
#include "mips.h"


/*  1.  Adder, ALU, ALU Control, ControlUnit, DataMemory, IM,
        Latch, MUX, PC, Registers, ShiftLeft2, SignExtend 정의
    2.  Single Cycle 구현
    3.  Pipeline 구현
    4.  Hazards 해결
*/

static void view_registers(int* registers);

int main(int argc, char* argv[]) {

    char* file_name = "./test_prog/input4.bin";

    FILE* fp = fopen(file_name, "rb");

    if (fp == NULL) {
        fprintf(stderr, "FILE OPEN FAILED");
        exit(EXIT_FAILURE);
    }

    FILE* fwp = fopen("output.txt", "w");

    if (fwp == NULL) {
        fprintf(stderr, "FILE OPEN FAILED");
        exit(EXIT_FAILURE);
    }

    unsigned int registers[32];

    initialize_registers(registers);

    int* memory = malloc(100000000 * sizeof(*memory));

    if (memory == NULL) exit(EXIT_FAILURE);

    memset(memory, -1, 100000000);

    int* mem_cursor = memory;

    while (feof(fp) == 0) {
        int ret;

        char buffer[4];

        for (int i = 0; i < 4; i++) {
            ret = fread(&buffer[3 - i], 1, 1, fp);
        }

        if (ret != 1) {

#ifdef __DEBUG_MODE__
            printf("FILE END");
#endif
            break;
        }

        int input = *(int*)buffer;

        *mem_cursor = input;

#ifdef __DEBUG_MODE__
        printf("%#X\n", *mem_cursor);
#endif

        mem_cursor++;
    }

    int count = 0;

    int pc = 0;

    int temp_pc = 0;

    int add_result = 0;

    bool PCSrc = false;

    while (1) {
        //if (pc == 0x14) registers[2] = 720;
        //if (pc == 0x1c) registers[2] = 264;

        IF_ID* if_id = fetch(&pc, add_result, PCSrc, memory, &count);

        if (pc == -1) break;

#ifdef __DEBUG_MODE__
        printf("IF %#x // pc : %x\n", if_id->instruction, pc);
#endif
        if (if_id->instruction == -1) break;

        ID_EX* id_ex = decode(if_id, registers);

        if ((id_ex->opcode == 2) || (id_ex->opcode == 3)) {
            int address = jump_address(if_id->instruction);
            temp_pc = ((JUMP_ADDRESS_FLAG) & (pc)) + (address << 2);
            PCSrc = false;
        }

#ifdef __DEBUG_MODE__
        printf("ID\n");
#endif

        EX_MEM* ex_mem = execute(id_ex);
#ifdef __DEBUG_MODE__
        printf("EX\n");
#endif

        free(id_ex->ex);

        add_result = ex_mem->add_result;
        
        MEM_WB* mem_wb = mem_write(ex_mem, &PCSrc, memory);
#ifdef __DEBUG_MODE__
        printf("MEM\n");
#endif
        
        free(ex_mem->m);

        write_back(mem_wb, registers);
#ifdef __DEBUG_MODE__
        printf("WB\n");

        fprintf(fwp, "%d : ", count);
        for (int i = 0; i < 32; i++) {
            fprintf(fwp, "%d ", registers[i]);
        }
        fprintf(fwp, "\n");

        view_registers(registers);

        fprintf(stdout, "\n\n\n");
        printf("\nR2 : %d  |  Count : %d\n", registers[2], count);
#endif

        free(mem_wb->wb);

        free(if_id);
        free(id_ex);
        free(ex_mem);
        free(mem_wb);
        count++;

        if (temp_pc != 0) {
            pc = temp_pc;
            temp_pc = 0;
        }
#ifdef __DEBUG_MODE__
        if (count % 10000000 == 0) {
            printf("count : %d\n", count);
        }
#endif // !__DEBUG_MODE__
    }

    printf("\nR2 : %d  |  Count : %d\n", registers[2], count);

    free(memory);

    fclose(fp);
    fclose(fwp);

    return 0;
}

#ifdef __DEBUG_MODE__
static void view_registers(int* registers) {

    char* str = "  R   E   G   I   S   T   E   R  ";

    for (int i = 0; i < 32; i++) {

        fprintf(stdout, "  %c \t|  %d[%x] ", str[i], i, registers[i]);

        int temp = registers[i];

        fprintf(stdout, "\n");
    }
}
#endif
