#include "mips.h"
#include <stdio.h>

int shift_length[] = {
    26, 21, 16, 11, 6
};

int mask[] = {
    0b11111100000000000000000000000000,
    0b00000011111000000000000000000000,
    0b00000000000111110000000000000000,
    0b00000000000000001111100000000000,
    0b00000000000000000000011111000000,
    0b00000000000000000000000000111111
};

int op_dict_keys[] = {
    0x0, 0x2, 0x3, 0x4, 0x5, 0x8, 0x9, 0xa,
    0xb, 0xc, 0xd, 0xf, 0x23, 0x24, 0x25, 0x28,
    0x29, 0x2b, 0x30, 0x38
};

char op_dict_values[] = {
    'R', 'J', 'J', 'I', 'I', 'I', 'I', 'I',
    'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I',
    'I', 'I', 'I', 'I'
};

int funct_keys[] = {
    0x0,    0x2,    0x8,    0x20,   0x21,   0x22,
    0x23,   0x24,   0x25,   0x27,   0x2a,   0x2b
};

int find_opcode_index(int opcode) {
    for (int i = 0; i < NUM_OF_OP; i++) {
        if (op_dict_keys[i] == opcode) return i;
    }

    return -1;
}

int find_funct_index(int funct) {
    for (int i = 0; i < NUM_OF_FUNCT; i++) {
        if (funct_keys[i] == funct) return i;
    }

    return -1;
}

int opcode_to_inst_type(int opcode) {
    int index;

    if ((index = find_opcode_index(opcode)) != -1) return op_dict_values[index];
}

void initialize_registers(int registers[]) {

    for (int i = 0; i < NUM_OF_REG; i++) {
        if (i == LR)
            registers[i] = LRvalue;
        else if (i == SP)
            registers[i] = SPvalue;
        else
            registers[i] = 0;
    }
}

int jump_address(int input) {
    return input & (mask[1] + mask[2] + mask[3] + mask[4] + mask[5]);
}

IF_ID* fetch(int* pc_ptr, int add_result, bool PCSrc, int* memory, int* count) {

    int pc = mux(PCSrc, *pc_ptr, add_result);

    if (pc == -1) {
        *pc_ptr = -1;
        return NULL;
    }

    int instruction = read_instruction(pc, (char*)memory);

    while (instruction == 0) {
        pc = pc + 4;
        instruction = read_instruction(pc, (char*)memory);
        (*count)++;
    }

    int new_pc_plus_four = pc + 4;

    *pc_ptr = new_pc_plus_four;

    IF_ID* if_id = malloc(sizeof(*if_id));

    if_id->pc_plus_four = new_pc_plus_four;
    if_id->instruction = instruction;
    if_id->valid = true;

    return if_id;
}

ID_EX* decode(IF_ID* if_id, int* registers) {
    int opcode = find_opcode(if_id->instruction);

    void** control_lines = control_unit(opcode);

    EX_control_line* ex = (EX_control_line*)control_lines[0];

    M_control_line* m = (M_control_line*)control_lines[1];

    WB_control_line* wb = (WB_control_line*)control_lines[2];

    int read_register_1 = (if_id->instruction & mask[1]) >> shift_length[1];
    int read_register_2 = (if_id->instruction & mask[2]) >> shift_length[2];

    int* read_data = operate_registers(registers, false, read_register_1, read_register_2, -1, -1);

    short imm = (short)(if_id->instruction & (mask[3] + mask[4] + mask[5]));

    int sign_ext_imm = sign_extend(imm);

    int zero_ext_imm = ZERO_IMMIDIATE_FLAG & sign_ext_imm;

    if ((opcode == 0xc) || (opcode == 0xd)) sign_ext_imm = zero_ext_imm;
    if (opcode == 0xf) sign_ext_imm = (sign_ext_imm << 16);

    int inst_20_16 = (if_id->instruction & mask[2]) >> shift_length[2];

    int inst_15_11 = (if_id->instruction & mask[3]) >> shift_length[3];

    ID_EX* id_ex = malloc(sizeof(*id_ex));

    id_ex->wb = wb;
    id_ex->m = m;
    id_ex->ex = ex;
    id_ex->pc_plus_four = if_id->pc_plus_four;
    id_ex->read_data = read_data;
    id_ex->sign_ext_imm = sign_ext_imm;
    id_ex->inst_20_16 = inst_20_16;
    id_ex->inst_15_11 = inst_15_11;
    id_ex->opcode = opcode;
    id_ex->valid = true;

    return id_ex;
}

EX_MEM* execute(ID_EX* id_ex) {
    int sign_ext_imm_sl2 = shitf_left_two(id_ex->sign_ext_imm);

    int add_result = adder(id_ex->pc_plus_four, sign_ext_imm_sl2);

    int ALUSrc = mux(id_ex->ex->alu_src, id_ex->read_data[1], id_ex->sign_ext_imm);

    bool zero = false;

    int funct = id_ex->sign_ext_imm & mask[5];

    int alu_input_a = id_ex->read_data[0];

    if ((id_ex->opcode == 0) && (funct == 0)) {
        int shamt = (id_ex->sign_ext_imm & mask[4]) >> shift_length[4];
        alu_input_a = shamt;
    }


    int alu_result = alu(alu_input_a, ALUSrc, &zero, id_ex->opcode, funct);

    int RegDst = mux(id_ex->ex->reg_dst, id_ex->inst_20_16, id_ex->inst_15_11);

    if (id_ex->opcode == 3) {
        RegDst = 31;
        alu_result = id_ex->pc_plus_four + 4;
    } else if ((id_ex->opcode == 0) && (funct == 8)) {
        add_result = id_ex->read_data[0];
        zero = true;
        id_ex->m->branch = true;
    }
    /*else if (id_ex->opcode == 0xf) {
        id_ex->wb->mem_to_reg = false;
        id_ex->wb->reg_write = true;
        RegDst = id_ex->inst_20_16;
    }*/

    EX_MEM* ex_mem = malloc(sizeof(*ex_mem));

    ex_mem->wb = id_ex->wb;
    ex_mem->m = id_ex->m;
    ex_mem->add_result = add_result;
    ex_mem->zero = zero;
    ex_mem->alu_result = alu_result;
    ex_mem->read_data_two = id_ex->read_data[1];
    ex_mem->reg_dst_result = RegDst;

    free(id_ex->read_data);

    return ex_mem;
}

MEM_WB* mem_write(EX_MEM* ex_mem, bool* PCSrc, int* memory) {
    bool branch = and_gate(ex_mem->m->branch, ex_mem->zero);

    *PCSrc = branch;
    
    int read_data = data_memory(ex_mem->alu_result, ex_mem->read_data_two, ex_mem->m->mem_write, ex_mem->m->mem_read, (char*)memory);

    MEM_WB* mem_wb = malloc(sizeof(*mem_wb));

    mem_wb->wb = ex_mem->wb;
    mem_wb->read_data = read_data;
    mem_wb->alu_result = ex_mem->alu_result;
    mem_wb->reg_dst_result = ex_mem->reg_dst_result;

    return mem_wb;
}

void write_back(MEM_WB* mem_wb, int* registers) {
    int write_data = mux(mem_wb->wb->mem_to_reg, mem_wb->alu_result, mem_wb->read_data);

    int write_register = mem_wb->reg_dst_result;

    operate_registers(registers, mem_wb->wb->reg_write, -1, -1, write_register, write_data);

    return;
}


int find_opcode(int instruction) {
    return ((instruction & mask[0]) >> shift_length[0]) & mask[5];
}