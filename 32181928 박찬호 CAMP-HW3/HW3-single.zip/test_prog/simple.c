void foo()
{
	return;
}
