#ifndef __MODE_H__
#define __MODE_H__

#define __DEBUG_MODE__

#undef __DEBUG_MODE__

#endif // !__MODE_H__
