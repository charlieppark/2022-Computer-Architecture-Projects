#ifndef __MIPS_H__

#define __MIPS_H__

#include "mode.h"

#include "components.h"

#define NUM_OF_OP 20

#define NUM_OF_FUNCT 12

#define NUM_OF_REG 32

#define LR 31

#define LRvalue 0xFFFFFFFF

#define SP 29

#define SPvalue 0x1000000

#define JUMP_ADDRESS_FLAG ((int)0b11110000000000000000000000000000)

#define UPPER_IMM_FLAG ((int)0b11111111111111110000000000000000)

#define ZERO_IMMIDIATE_FLAG ((int)0b00000000000000001111111111111111)

int find_opcode_index (int opcode);

int find_funct_index (int funct);

int opcode_to_inst_type (int opcode);

void initialize_registers(int registers[]);


IF_ID* fetch(int* pc_plus_four, int add_result, bool PCSrc, int* memory, int* count);

ID_EX* decode(IF_ID* if_id, int* registers);

EX_MEM* execute(ID_EX* id_ex);

MEM_WB* mem_write(EX_MEM* ex_mem, bool* PCSrc, int* memory);

void write_back(MEM_WB* mem_wb, int* registers);

int find_opcode(int instruction);



#endif // !__MIPS_H__